<path to Spark>/bin/spark-submit --master local[2] --jars <path to jar package>/elasticsearch-spark-20_2.11-6.5.4.jar <path to spark.py>/spark.py
